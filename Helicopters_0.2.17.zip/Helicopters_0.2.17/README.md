# factorio-helicopters
"Helicopters" mod for factorio. Actually interesting stuff is in logic/.

[Mod Portal](https://mods.factorio.com/mods/kumpu/Helicopters)

[Forum thread](https://forums.factorio.com/viewtopic.php?f=93&t=50631)
