--- For working with energy strings
-- @classmod Joules

local Joules = {}

return Joules
